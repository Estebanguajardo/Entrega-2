document.addEventListener('DOMContentLoaded', function() {
    const formularioRegistro = document.getElementById('formulario-registro');
    const contenedorErrores = document.getElementById('errores');
    const modalRegistroExitoso = document.getElementById('modal-registro-exitoso');

    function validarFormulario(event) {
        event.preventDefault();

        const nombre = document.getElementById('nombre').value;
        const apellido = document.getElementById('apellido').value;
        const rut = document.getElementById('rut').value;
        const telefono = document.getElementById('telefono').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        contenedorErrores.style.display = 'none';
        contenedorErrores.innerHTML = '';

        if (!nombre ||!apellido ||!rut ||!telefono ||!email ||!password) {
            contenedorErrores.innerHTML += 'Por favor, completa todos los campos.<br>';
        }

        if (password.length < 8) {
            contenedorErrores.innerHTML += 'La contraseña debe tener al menos 8 caracteres.<br>';
        }

        if (telefono.length < 9) {
            contenedorErrores.innerHTML += 'El teléfono debe tener al menos 9 dígitos.<br>';
        }

        const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!regexEmail.test(email)) {
            contenedorErrores.innerHTML += 'Por favor, ingresa un correo electrónico válido.<br>';
        }

        if (contenedorErrores.innerHTML) {
            contenedorErrores.style.display = 'block';
            return;
        }

        // Guardar el correo electrónico y la contraseña en el localStorage
        localStorage.setItem('email', email);
        localStorage.setItem('password', password);

        // Mostrar el modal de registro exitoso
        modalRegistroExitoso.style.display = 'block';

        // Redirigir a home.html después de 4 segundos
        setTimeout(function() {
            window.location.href = 'home.html';
        }, 4000);
    }

    formularioRegistro.addEventListener('submit', validarFormulario);
});
