document.addEventListener('DOMContentLoaded', function() {
    // Selección de elementos del DOM
    const botonesAgregarCarrito = document.querySelectorAll('.custom-btn');
    const tablaCarrito = document.querySelector('#lista-carrito tbody');
    const totalPagar = document.querySelector('#total-pagar');
    const iconoCarrito = document.getElementById('carrito-icon');
    const contenedorCarrito = document.getElementById('carrito');
    const botonVaciarCarrito = document.getElementById('vaciar-carrito');
    const botonPagarCarrito = document.getElementById('pagar-carrito');

    // Carga de productos del carrito desde localStorage
    let productosEnCarrito = JSON.parse(localStorage.getItem('productosEnCarrito')) || [];

    // Función para mostrar los productos en el carrito
    function mostrarProductosEnCarrito() {
        tablaCarrito.innerHTML = ''; // Limpiar tabla del carrito

        productosEnCarrito.forEach((producto, indice) => {
            if (producto.precio !== null && producto.precio !== undefined) {
                const fila = document.createElement('tr');
                fila.innerHTML = `
                    <td><img src="${producto.imagen}" alt="${producto.nombre}" class="img-fluid" style="max-width: 50px;"></td>
                    <td>${producto.nombre}</td>
                    <td>$${producto.precio.toFixed(2)}</td>
                    <td><button class="btn btn-danger btn-sm eliminar-item" data-indice="${indice}">Eliminar</button></td>
                `;
                tablaCarrito.appendChild(fila);
            }
        });

        calcularTotal(); // Calcular el total después de mostrar los productos
    }

    // Función para calcular el total a pagar
    function calcularTotal() {
        let total = 0;
        productosEnCarrito.forEach(producto => {
            if (producto.precio !== null && producto.precio !== undefined) {
                total += producto.precio;
            }
        });

        // Mostrar el total formateado a dos decimales
        totalPagar.textContent = total.toFixed(2);
    }

    // Función para guardar productos en localStorage
    function guardarProductosEnCarrito() {
        localStorage.setItem('productosEnCarrito', JSON.stringify(productosEnCarrito));
    }

    // Función para redirigir a check.html con los datos del carrito
    function redireccionarAPagar() {
        const productosJSON = JSON.stringify(productosEnCarrito);
        const urlParams = new URLSearchParams({ productos: productosJSON });

        // Redirigir a check.html con los parámetros de URL
        window.location.href = `check.html?${urlParams.toString()}`;
    }

    // Función para agregar un producto al carrito
    function agregarProductoCarrito(boton) {
        const card = boton.parentElement;
        const nombre = card.querySelector('.card-title').textContent;
        const precio = parseFloat(card.querySelector('.card-text').textContent.replace('$', ''));

        if (precio !== null && precio !== undefined) {
            const imagen = card.parentElement.querySelector('.card-img-top').src;
            const nuevoProducto = { nombre, precio, imagen };

            productosEnCarrito.push(nuevoProducto);
            guardarProductosEnCarrito();
            mostrarProductosEnCarrito();
        }
    }

    // Función para vaciar el carrito
    function vaciarCarrito() {
        productosEnCarrito = [];
        guardarProductosEnCarrito();
        mostrarProductosEnCarrito();
        alert('El carrito ha sido vaciado con éxito.');
    }

    // Función para manejar el evento de eliminar un producto
    function eliminarProducto(indice) {
        productosEnCarrito.splice(indice, 1);
        guardarProductosEnCarrito();
        mostrarProductosEnCarrito();
    }

    // Eventos de escucha
    botonesAgregarCarrito.forEach(boton => {
        boton.addEventListener('click', function() {
            agregarProductoCarrito(this);
        });
    });

    iconoCarrito.addEventListener('click', () => {
        contenedorCarrito.classList.toggle('show');
    });

    botonVaciarCarrito.addEventListener('click', function() {
        vaciarCarrito();
    });

    tablaCarrito.addEventListener('click', function(evento) {
        if (evento.target.classList.contains('eliminar-item')) {
            const indice = parseInt(evento.target.getAttribute('data-indice'));
            eliminarProducto(indice);
        }
    });

    botonPagarCarrito.addEventListener('click', redireccionarAPagar);

    // Mostrar los productos del carrito al cargar la página
    mostrarProductosEnCarrito();
});
