document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Obtener los valores del formulario
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;

    // Verificar si los campos están vacíos
    if (email === '' || password === '') {
        // Si alguno de los campos está vacío, mostrar el modal de alerta
        var emptyFieldsModal = new bootstrap.Modal(document.getElementById('emptyFieldsModal'));
        emptyFieldsModal.show();

        // Cierra el modal de alerta automáticamente después de 5 segundos
        setTimeout(function() {
            emptyFieldsModal.hide();
        }, 5000); // 5000 milisegundos = 5 segundos
        return; // Finaliza la función para evitar seguir con las comprobaciones
    }

    // Recuperar datos almacenados en localStorage
    var storedEmail = localStorage.getItem('email');
    var storedPassword = localStorage.getItem('password');

    if (email === storedEmail && password === storedPassword) {
        // Si las credenciales coinciden, mostrar el modal de bienvenida
        var welcomeModal = new bootstrap.Modal(document.getElementById('welcomeModal'));
        welcomeModal.show();

        // Redirige al usuario a home.html después de un breve retraso
        setTimeout(function() {
            window.location.href = "home.html";
        }, 1000); // Espera 1 segundo antes de redirigir
    } else if (email !== storedEmail) {
        // Si el correo electrónico no está registrado, mostrar el modal de alerta de usuario no registrado
        var notRegisteredModal = new bootstrap.Modal(document.getElementById('notRegisteredModal'));
        notRegisteredModal.show();

        // Cierra el modal de alerta automáticamente después de 5 segundos
        setTimeout(function() {
            notRegisteredModal.hide();
        }, 5000); // 5000 milisegundos = 5 segundos
    } else {
        // Si las credenciales no coinciden, mostrar el modal de alerta
        var alertModal = new bootstrap.Modal(document.getElementById('alertModal'));
        alertModal.show();

        // Cierra el modal de alerta automáticamente después de 5 segundos
        setTimeout(function() {
            alertModal.hide();
        }, 5000); // 5000 milisegundos = 5 segundos
    }
});
