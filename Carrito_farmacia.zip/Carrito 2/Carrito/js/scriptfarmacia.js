// URL de la API para obtener las farmacias
const URL = "https://midas.minsal.cl/farmacia_v2/WS/getLocales.php";

// Realiza una solicitud fetch a la API
fetch(URL)
    .then((response) => response.json()) // Convierte la respuesta en JSON
    .then((data) => {
        const pharmacies = data; // Almacena los datos de las farmacias

        // Rellena el dropdown con los nombres de las comunas
        const comunaFilter = document.getElementById('comuna-filter');
        const comunas = [...new Set(pharmacies.map(pharmacy => pharmacy.comuna_nombre))]; // Obtiene los nombres únicos de las comunas
        comunas.forEach(comuna => {
            const option = document.createElement('option'); // Crea un nuevo elemento option
            option.value = comuna; // Establece el valor del option
            option.textContent = comuna; // Establece el texto del option
            comunaFilter.appendChild(option); // Añade el option al dropdown
        });

        // Muestra todas las farmacias en la página inicialmente
        displayPharmacies(pharmacies);

        // Añade un event listener al dropdown para filtrar las farmacias por comuna
        comunaFilter.addEventListener('change', () => {
            const selectedComuna = comunaFilter.value; // Obtiene el valor seleccionado del dropdown
            // Filtra el array de farmacias basado en la comuna seleccionada
            const filteredPharmacies = pharmacies.filter(pharmacy => pharmacy.comuna_nombre === selectedComuna);
            // Muestra las farmacias filtradas en la página
            displayPharmacies(filteredPharmacies);
        });

        // Función para mostrar las farmacias en una tabla
        function displayPharmacies(pharmacies) {
            const apiDataDiv = document.getElementById("api-data");
            apiDataDiv.innerHTML = ""; // Limpia el contenido anterior

            // Crea la tabla
            const table = document.createElement("table");
            table.classList.add('table', 'table-striped', 'table-bordered'); // Aplica estilos Bootstrap a la tabla

            // Crea el encabezado de la tabla
            const tableHeader = document.createElement("thead");
            const headerRow = document.createElement("tr");
            ["Nombre", "Comuna", "Dirección", "Horario de Apertura", "Horario de Cierre", "Teléfono", "Ubicación"].forEach(headerText => {
                const th = document.createElement("th");
                th.textContent = headerText;
                headerRow.appendChild(th);
            });
            tableHeader.appendChild(headerRow);
            table.appendChild(tableHeader);

            // Crea el cuerpo de la tabla
            const tableBody = document.createElement("tbody");
            pharmacies.forEach((item) => {
                const row = document.createElement("tr");
                ["local_nombre", "comuna_nombre", "local_direccion", "funcionamiento_hora_apertura", "funcionamiento_hora_cierre", "local_telefono"].forEach(data => {
                    const td = document.createElement("td");
                    td.textContent = item[data];
                    row.appendChild(td);
                });

                // Crea la columna de ubicación con un botón para abrir la dirección en Google Maps
                const locationTd = document.createElement("td");
                const locationButton = document.createElement("a");
                locationButton.classList.add('btn', 'btn-primary'); // Estilo Bootstrap para el botón
                locationButton.textContent = "Ir";
                
                // Crea el enlace a Google Maps
                const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(item.local_direccion)}`;
                locationButton.href = googleMapsUrl;
                locationButton.target = "_blank"; // Abre el enlace en una nueva pestaña
                locationTd.appendChild(locationButton);
                
                // Añade la columna a la fila
                row.appendChild(locationTd);
                
                // Añade la fila al cuerpo de la tabla
                tableBody.appendChild(row);
            });
            
            // Añade el cuerpo de la tabla a la tabla
            table.appendChild(tableBody);
            
            // Añade la tabla al elemento api-data
            apiDataDiv.appendChild(table);
        }
    })
    .catch((error) => {
        console.error(error); // Muestra el error en la consola si ocurre uno
    });
