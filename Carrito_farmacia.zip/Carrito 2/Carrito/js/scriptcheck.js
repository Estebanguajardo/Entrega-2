document.addEventListener('DOMContentLoaded', function() {
    // Obtener los productos del carrito desde la URL
    const urlParams = new URLSearchParams(window.location.search);
    const productosJSON = urlParams.get('productos');
    let productosEnCarrito = JSON.parse(productosJSON) || [];

    // Calcular y mostrar el total a pagar al cargar la página
    const totalPagarCheck = document.getElementById('total-pagar-check');
    let total = 0;
    productosEnCarrito.forEach(producto => {
        if (producto.precio!== null && producto.precio!== undefined) {
            total += producto.precio;
        }
    });
    totalPagarCheck.textContent = total.toFixed(2);

    // Función para mostrar los productos en la tabla
    function mostrarProductosEnTabla() {
        const tabla = document.getElementById('resumen-carrito');
        tabla.innerHTML = ''; // Limpiar la tabla
        productosEnCarrito.forEach(producto => {
            const fila = document.createElement('tr');
            fila.innerHTML = `
                <td><img src="${producto.imagen}" alt="" class="img-fluid" style="max-width: 50px;"></td>
                <td>${producto.nombre}</td>
                <td>${producto.precio.toFixed(2)}</td>
                <td><button class="btn btn-danger btn-sm eliminar-producto">Eliminar</button></td>
            `;
            tabla.appendChild(fila);
        });
    }

    // Función para eliminar un producto del carrito
    function eliminarProductoDelCarrito(indice) {
        productosEnCarrito.splice(indice, 1);
        // Actualizar el total a pagar
        totalPagarCheck.textContent = calcularTotal().toFixed(2);
        // Mostrar los productos actualizados
        mostrarProductosEnTabla();
    }

    // Función para calcular el total a pagar
    function calcularTotal() {
        let total = 0;
        productosEnCarrito.forEach(producto => {
            if (producto.precio!== null && producto.precio!== undefined) {
                total += producto.precio;
            }
        });
        return total;
    }

    // Agregar controlador de eventos para los botones de eliminar
    document.getElementById('resumen-carrito').addEventListener('click', function(event) {
        if (event.target.classList.contains('eliminar-producto')) {
            const indice = Array.from(this.children).indexOf(event.target.parentElement);
            eliminarProductoDelCarrito(indice);
        }
    });

    // Mostrar los productos al cargar la página
    mostrarProductosEnTabla();
});

